//
//  ViewController.swift
//  AlexaNotes
//
//  Created by Sayon the Great on 6/23/17.
//  Copyright © 2017 SayonTheGreat. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource
{
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var tableView: UITableView?
    
    var fetchedNotes = [AlexaNotes]()
    
    override func viewDidLoad()
    {
        //print ("abcde")
        super.viewDidLoad()
        //textView.text = "testing text"
        
        do
        {
            tableView?.dataSource = self
        }
        catch
        {
            print ("ERROR unwrapping")
        }
        
        parseData()
        
        // Do any additional setup after loading the view, typically from a nib.
        /*
        let url = URL(string: "https://alexaskillnotesapp.herokuapp.com/Notes/GetNotes")
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error != nil
            {
                print("ERROR")
            }
            else
            {
                if let content = data
                {
                    do
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        print(myJson)
                    }
                    catch
                    {
                        
                    }
                }
            }
        }
        task.resume()
        */
    }

    /*override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }*/
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return fetchedNotes.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = fetchedNotes[indexPath.row].name
        cell?.detailTextLabel?.text = fetchedNotes[indexPath.row].text
        
        
        //self.textView?.text = self.fetchedNotes[indexPath.row].text
        
        return cell!
    }

    
    
    
    
    
    func parseData() -> Void
    {
        
        fetchedNotes = []
        
        let url = "https://alexaskillnotesapp.herokuapp.com/Notes/GetNotes"
        
        var request = URLRequest(url:URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil
            {
                print(error as Any)
            }
            else
            {
                do
                {
                    let fetchData = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves)  as! NSArray
                    for eachNote in fetchData
                    {
                        let note = eachNote as! [String : Any]
                        let name = note["name"] as? String ?? ""
                        let text = note["text"] as? String ?? ""
                        
                        if(name != "" && text != ""){
                            self.fetchedNotes.append(AlexaNotes(name:name,text:text))
                        }
                    }
                    //print(self.fetchedNotes)
                    //self.textView?.text = "\(fetchData as! NSArray)"
                    //self.textView?.text = self.tempStr
                    //print(self.textView?.text)
                    self.tableView?.reloadData()
                }
                catch
                {
                    print("error 2")
                }
            }
        }
        task.resume()
    }
}

class AlexaNotes
{
    var name: String
    var text: String
    
    init(name: String, text: String)
    {
        self.name = name
        self.text = text
    }
}










