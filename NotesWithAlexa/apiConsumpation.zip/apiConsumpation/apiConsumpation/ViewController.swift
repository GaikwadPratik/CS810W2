//
//  ViewController.swift
//  apiConsumpation
//
//  Created by Pratik on 8/22/17.
//  Copyright © 2017 Pratik. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var fetchedNotes = [AlexaNotes]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        parseData()
    }

    func parseData() -> Void {
        
        fetchedNotes = []
        
        let url = "https://alexaskillnotesapp.herokuapp.com/Notes/GetNotes"
        
        var request = URLRequest(url:URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil{
                print(error as! Any)
            }
            else{
                
                do{
                    let fetchData = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves)  as! NSArray
                    
                    for eachNote in fetchData {
                        let note = eachNote as! [String : Any]
                        
                        let name = note["name"] as? String ?? ""
                        let text = note["text"] as? String ?? ""
                        
                        if(name != "" && text != ""){
                            self.fetchedNotes.append(AlexaNotes(name:name,text:text))
                        }
                    }
                    
                    print(self.fetchedNotes)
                    
                }
                catch{
                    print("error 2")
                }
                
            }
        }
        task.resume()
    }
}

class AlexaNotes{
    
    var name: String
    var text: String
    
    init(name: String, text: String) {
        self.name = name
        self.text = text
    }
}

